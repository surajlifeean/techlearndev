  <script src="{{asset('Admin/js/jquery.min.js')}}"></script>
  <!-- Bootstrap -->
  <script src="{{asset('Admin/js/bootstrap.js')}}"></script>
  <!-- App -->
  <script src="{{asset('Admin/js/app.js')}}"></script>
  <script src="{{asset('Admin/js/app.plugin.js')}}"></script>
  <script src="{{asset('Admin/js/slimscroll/jquery.slimscroll.min.js')}}"></script>
    <script src="{{asset('Admin/js/charts/easypiechart/jquery.easy-pie-chart.js')}}"></script>
  <script src="{{asset('Admin/js/charts/sparkline/jquery.sparkline.min.js')}}"></script>
  <script src="{{asset('Admin/js/charts/flot/jquery.flot.min.js')}}"></script>
  <script src="{{asset('Admin/js/charts/flot/jquery.flot.tooltip.min.js')}}"></script>
  <script src="{{asset('Admin/js/charts/flot/jquery.flot.resize.js')}}"></script>
  <script src="{{asset('Admin/js/charts/flot/jquery.flot.grow.js')}}"></script>
  <script src="{{asset('Admin/js/charts/flot/demo.js')}}"></script>

  <script src="{{asset('Admin/js/calendar/bootstrap_calendar.js')}}"></script>
  <script src="{{asset('Admin/js/calendar/demo.js')}}"></script>

  <script src="{{asset('Admin/js/sortable/jquery.sortable.js')}}"></script>

  <script src="{{asset('js/parsley.min.js')}}"></script>

  <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
  