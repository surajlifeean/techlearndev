  <meta charset="utf-8" />
  <title>TechLearn | Admin</title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="{{asset('Admin/css/bootstrap.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('Admin/css/animate.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('Admin/css/font-awesome.min.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('Admin/css/font.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('Admin/js/calendar/bootstrap_calendar.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('Admin/css/app.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{asset('css/parsley.css')}}" type="text/css" />
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->