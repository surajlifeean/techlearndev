
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>Code</title>
    <link href="" rel="shortcut icon" type="image/x-icon" />
    <meta rel="shortcut icon" />
    <meta name="description" content=" ">
    <meta name="keywords" content=" ">
    <!-- css section -->                
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap-grid.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap-reboot.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/lightslider.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('font/fonts.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/custom.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/media.css')}}" />
    <!-- Javascript section -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/lightslider.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/custom.js')}}"></script>
    <link rel="stylesheet" href="{{asset('css/parsley.css')}}" type="text/css" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/easy-responsive-tabs.css')}}" />

    <style type="text/css">
        .how-works-list{
            padding-left: 0px;
        }
    </style>
    @yield('stylesheets')
</head>
