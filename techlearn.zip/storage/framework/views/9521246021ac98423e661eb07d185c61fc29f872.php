<?php $__env->startSection('content'); ?>


<h1>Dashboard</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>