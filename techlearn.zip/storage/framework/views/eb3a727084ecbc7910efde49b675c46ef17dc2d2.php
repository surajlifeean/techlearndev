    <header>
        <div class="nav">
            <div class="container">
                <div class="row align-items-center">
                     <div class="logo_wrap header-left col-md-3 col-6">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" />
                        </a>
                    </div>
                    
                    <div class="col-md-9 col-6 header-right text-right">
                    <a href="javascript:void(0)" class="menu-button"><i class="fa fa-bars"></i></a>
                    <div class="menu-container">    
                    <ul class="top-menu">
                        <li><a href="<?php echo e(url('/learn')); ?>">Learn</a></li>
                        <li><a href="#">Business</a></li>
                        <li><a href="#">Support</a></li>
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>">Sign in</a></li>
                        <li><a class="crest-account" href="<?php echo e(route('register')); ?>">Create Account</a></li>
                        <?php else: ?>
                        <li><a class="crest-account" href="<?php echo e(route('profile.index')); ?>">Dashboard</a></li>
                         <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>

                        <?php endif; ?>
                        
                    </ul>
                    </div>  
                </div>
                </div>
               
                
            </div>
        </div>
    </header>
     