 <header>
        <div class="nav">
            <div class="container">
                <div class="logo_wrap left">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="images/logo.png" alt="logo" />
                    </a>
                </div>
                <div class="col-md-7 right">
                    
                    <ul class="top-menu">
                        <li><a href="<?php echo e(url('/learn')); ?>">Learn</a></li>
                        <li><a href="#">Business</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#">Sign in</a></li>
                        <li><a class="crest-account" href="#">Create Account</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>