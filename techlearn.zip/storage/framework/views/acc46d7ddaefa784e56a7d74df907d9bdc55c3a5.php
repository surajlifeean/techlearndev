<?php $__env->startSection('content'); ?>


<section id="content">
<section class="vbox">
<section class="scrollable padder">

 <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Home</a></li>
                <li><a href="<?php echo e(route('video-management.index')); ?>">Video Management</a></li>
                <li><a href="<?php echo e(route('video-management.index')); ?>">Video List</a></li>
               
              </ul>

 
                      <header class="panel-heading">
                        <span class="h4">Video Listing</span>
                      </header>

                       <header class="header bg-white b-b clearfix">
                  <div class="row m-t-sm">
                    <div class="col-sm-8 m-b-xs">
                      <!-- <a href="#subNav" data-toggle="class:hide" class="btn btn-sm btn-default active"><i class="fa fa-caret-right text fa-lg"></i><i class="fa fa-caret-left text-active fa-lg"></i></a> -->
                      <div class="btn-group">
                       <a href="<?php echo e(route('video-management.index')); ?>"> <button type="button" class="btn btn-sm btn-default" title="Refresh"><i class="fa fa-refresh"></i></button></a>
                        <button type="button" class="btn btn-sm btn-default delete-many" title="Remove"><i class="fa fa-trash-o"></i></button>

                          &nbsp;&nbsp;
                        <a href="javascript:void(0)" class="active-status" aria-label="Left Align" onclick="changebulkstatus('A')"  title="Deactivate Newsletter Subscription">
                       <i class="fa fa-lock" aria-hidden="true"></i>
                      </a>
                 
                  &nbsp;&nbsp;
                  <a href="javascript:void(0)" class="inactive-status" aria-label="Left Align" onclick="changebulkstatus('I')"  title="Activate Newsletter Subscription">
                       <i class="fa fa-unlock" aria-hidden="true"></i>
                      </a>
                      </div>
                      <a href="<?php echo e(route('video-management.create')); ?>" class="btn btn-sm btn-default"><i class="fa fa-plus"></i>Add New video</a>
                    </div>

                     <form action="<?php echo e(route('video-search')); ?>" method="get">
                    <div class="col-sm-4 m-b-xs">
                      <div class="input-group">
                   
                      <input type="text" class="input-sm form-control" name="search" value="<?php echo e(session('search')); ?>"  placeholder="Search By Title Or Caption">
                        <span class="input-group-btn">
                            
                          <button class="btn btn-sm btn-default" type="submit">Go!</button>
   
                        </span>
                      
                      </div>
                    </div>
                    </form>
                  </div>
                </header>



                
                <section class="scrollable wrapper w-f">
                  <section class="panel panel-default">
                    <div class="table-responsive">
                      <table class="table table-striped m-b-none">
                        <thead>
                          <tr>
                            <th width="20"><input type="checkbox" value="" class="checkAll"></th>
                            <!-- <th width="20"></th> -->
                            <th>Title</th>
                            
                            <th>Caption</th>
                            
                            <th>Video Link</th>
                            <th>Created At</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>

				<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <?php

                    $url = $value->video_link;
                    $urlParts = explode("/", parse_url($url, PHP_URL_PATH));
                    $videoId = (int)$urlParts[count($urlParts)-1];
                    

            ?>
                          <tr>

                            <td><input type="checkbox" name="del[]" value="<?php echo e($value->id); ?>" id="checked"></td>

                            <td><?php echo e($value->title); ?></td>
                            <td><?php echo e($value->caption); ?>

                            <td>

            <?php

                    $url = $value->video_link;
                    $urlParts = explode("/", parse_url($url, PHP_URL_PATH));
                    $videoId = (int)$urlParts[count($urlParts)-1];
                    

            ?>
              <button type="button" class="button-common btn btn-primary video-btn" data-toggle="modal" data-src="https://player.vimeo.com/video/<?php echo e($videoId); ?>?title=0&byline=0&portrait=0&transparent=0" data-target="#myModal">
                         <i class="fa fa-eye" aria-hidden="true"></i>
                        </button>
                        

                            
                            

                            </td>

                            <td><?php echo e(date('jS M, Y', strtotime($value->created_at))); ?></td>
                            <td>
                                <!-- <?php if($value->status=='A'): ?>
           <a href="javascript:void(0)" class="active-status" aria-label="Left Align" onclick="changestatus('A',<?php echo e($value->id); ?>)" data-toggle="tooltip" title="Deactivate Product">
                       <i class="fa fa-unlock" aria-hidden="true"></i>
                      </a>
                 
                  <?php else: ?>
                  <a href="javascript:void(0)" class="inactive-status" aria-label="Left Align" onclick="changestatus('I',<?php echo e($value->id); ?>)" data-toggle="tooltip" title="Activate Product">
                       <i class="fa fa-lock" aria-hidden="true"></i>
                      </a>
                   

                  <?php endif; ?> -->
                  <button class="btn btn-primary btn-rounded formConfirm" data-form="#frmStatus-<?php echo e($value->id); ?>" data-title="Status Change" data-message="Are you sure, you want to change the status ?" >
                                        <?php if($value->status == 'I'){ ?>
                                            <i title="Inactive" style="margin-right: 0;" class="fa fa-lock" aria-hidden="true"></i>
                                        <?php } else { ?>
                                            <i title="Active" style="margin-right: 0;" class="fa fa-unlock" aria-hidden="true"></i>
                                        <?php } ?>
                                    </button>
                                    <?php echo Form::open(array(
                                            'url' => route('admin.video.statuschange', array($value->id)),
                                            'method' => 'get',
                                            'style' => 'display:none',
                                            'id' => 'frmStatus-' . $value->id,
                                            'status' => 'frmStatus-' . $value->status,
                                        )); ?>

                                    <?php echo Form::submit('Submit'); ?>

                                    <?php echo Form::close(); ?>

                   <!-- 
                     <?php echo Html::LinkRoute('video-management.edit',null,array($value->id),array('class'=>"fa fa-pencil-square-o",'data-toggle'=>"tooltip",'title'=>"Edit video")); ?> -->
                      <a href="<?php echo e(route('video-management.edit',$value->id)); ?>" class="btn btn-info btn-rounded"><i class="fa fa-pencil-square-o"></i></a>

                        <!-- <a href="#" class="delete-icon" id="<?php echo e($value->id); ?>" aria-label="Left Align" data-toggle="tooltip" title="Delete video">
                			 <i class="fa fa-trash-o" aria-hidden="true"></i>
             					</a> -->  <!-- delete icon that submits the form -->
                        
                        <button class="btn btn-danger btn-rounded formConfirm" data-form="#frmDelete-<?php echo e($value->id); ?>" data-title="Delete video" data-message="Are you sure, you want to delete this video ?" >
                                        <i title="Delete" style="margin-right: 0;" class="fa fa-trash-o" aria-hidden="true"></i>
                                    </button>
                                    <?php echo Form::open(array(
                                            'url' => route('admin.video.delete', array($value->id)),
                                            'method' => 'get',
                                            'style' => 'display:none',
                                            'id' => 'frmDelete-'.$value->id
                                        )); ?>

                                    <?php echo Form::submit('Submit'); ?>

                                    <?php echo Form::close(); ?>                     
             					 

                        <a href="<?php echo e(route('video-management.show',$value->id)); ?>" data-toggle="tooltip" title="video Details" class="btn btn-info btn-rounded"><i class="fa fa-search-plus"></i></a>

                            </td>
                           
                          </tr>

                    <?php echo Form::open(['route'=>['video-management.destroy',$value->id], 'method'=>'DELETE','class'=>'delete-video','id'=>'delete'.$value->id]); ?>

                    <?php echo Form::close(); ?>




                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                      </table>
                    </div>
                  </section>
                </section>

<?php echo $videos->links(); ?>



<div> Showing <?php echo $videos->count(); ?>|<?php echo $videos->total(); ?></div>
    
      


      <div class="modal fade" id="formConfirm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="frm_title">Delete</h4>
      </div>
      <div class="modal-body" id="frm_body">Are you sure, you want to delete this Topic ?</div>
      <div class="modal-footer">
        <button style='margin-left:10px;' type="button" class="btn btn-danger col-sm-2 pull-right" id="frm_submit">Confirm</button>
        <button type="button" class="btn btn-primary col-sm-2 pull-right" data-dismiss="modal" id="frm_cancel">Cancel</button>
      </div>
    </div>
  </div>
</div>                
                 
                     


</section>
</section>
</section>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">

      
      <div class="modal-body">

       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>        
        <!-- 16:9 aspect ratio -->
<div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="" id="video" frameborder="0" title="Funny Cat Videos For Kids" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen="" data-ready="true"></iframe>
</div>
        
        
      </div>

    </div>
  </div>
</div> 


    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

$(document).ready(function(){

     
  $('.formConfirm').on('click', function(e) {
    //alert();
        e.preventDefault();
        var el = $(this);
        //alert(el);
        var title = el.attr('data-title');
        var msg = el.attr('data-message');
        var dataForm = el.attr('data-form');
        
        $('#formConfirm')
        .find('#frm_body').html(msg)
        .end().find('#frm_title').html(title)
        .end().modal('show');
        
        $('#formConfirm').find('#frm_submit').attr('data-form', dataForm);
  });
  $('#formConfirm').on('click', '#frm_submit', function(e) {
        var id = $(this).attr('data-form');
        //alert(id);
        $(id).submit();
  });
});
</script>

    <script type="text/javascript">

    $(document).ready(function() {

    // Gets the video src from the data-src on each button

    var $videoSrc;  
    $('.video-btn').click(function() {
    $videoSrc = $(this).data( "src" );
    });
    console.log($videoSrc);



    // when the modal is opened autoplay it  
    $('#myModal').on('shown.bs.modal', function (e) {

    // set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
    $("#video").attr('src',$videoSrc + "?rel=0&amp;showinfo=0&amp;modestbranding=1&amp;autoplay=1" ); 
    })


    // stop playing the youtube video when I close the modal
    $('#myModal').on('hide.bs.modal', function (e) {
    // a poor man's stop video
    $("#video").attr('src',$videoSrc); 
    }) 






    // document ready  
    });



    </script>




<script type="text/javascript">
  
  $('.delete-icon').click(function(e){
    alert();
    e.preventDefault();
    var id=$(this).attr('id');
   
    var r = confirm("Are You Sure You Wanna Delete The video?");
    if (r == true) {
       $("#delete"+id).submit();
    } 
    
  });
  
</script>

<script>
var maxid=0;
$(document).ready(function(){
    
    $("input[type='checkbox']:not(.checkAll)").each(function(){
      maxid++;
    })
});
</script>




<script type="text/javascript">
var id;

$(".checkAll").change(function(){
  
  if($(this).is(':checked')){

    $("input[type='checkbox']").prop('checked', true);

  }else{
    $("input[type='checkbox']").prop('checked', false);
  }
  id = $("input[type='checkbox']:not(.checkAll):checked").map(function() {
                       return this.value;
                   }).get().join();

});

$("input[type='checkbox']:not(.checkAll)").change(function(){

  id = $("input[type='checkbox']:not(.checkAll):checked").map(function() {
                       return this.value;
                   }).get().join();
  if(!id)
    $(".checkAll").prop('checked', false);

  
   var arr=id.split(",");
    var mid=arr.length;
   

  if(maxid==mid)
   $(".checkAll").prop('checked', true);
  if(maxid>mid)
    $(".checkAll").prop('checked', false);

  
});

</script>

<script type="text/javascript">
  function changebulkstatus(status){
  /*alert(id);*/
  if(!id){
    alert("Please Select Some Items To Activate/Deactivate");
  }
  else{
    var r = confirm("Are You Sure You Wanna Change the status ?");
    if (r == true) {
    console.log(id);
    $.ajax({
        url:"<?php echo e(route('bulk-video-status')); ?>", 
        type:"get",
        data:{IDs:id,status:status},
        success: function(result){
          //alert(result);
          console.log(result);
          //location.reload();
          //location.reload();
          window.parent.location.reload();
        
        $("input[type='checkbox']").prop('checked', false);
    }});

   }//if ends
  }
}



$('.delete-many').click(function(){

  if(!id)
    alert("Please Select Some Items To Delete");
  else{
    var r = confirm("Are You Sure You Wanna Delete The Video ?");
    if (r == true) {
     //alert(id);
    $.ajax({
        url:"<?php echo e(route('video-bulk-delete')); ?>", 
        type:"get",
        data:{IDs:id},
        success: function(result){
      //alert(result);
            
          //location.reload();
           window.parent.location.reload();
          $("input[type='checkbox']").prop('checked', false);

    }});

  }//if ends
}

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>