<?php $__env->startSection('content'); ?>


<section id="content">
<section class="vbox">
<section class="scrollable padder">

 <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Home</a></li>
                <li><a href="<?php echo e(route('course-management.index')); ?>">Review Management</a></li>
                <li><a href="<?php echo e(route('course-management.create')); ?>">Add Review</a></li>
               
              </ul>

 
                      <header class="panel-heading">
                        <span class="h4">Add Review</span>
                      </header>

                      
                 
                     
                      <header class="panel-heading">
                        <strong>Enter The Review Details</strong>
                      </header>
                      <?php echo e(Form::model($review,['route' =>['review-management.update',$review->id],'method'=>'PUT','files' => true, 'class'=>'form-horizontal course-form','data-parsley-validate'])); ?>

                      <div class="panel-body">                   
                        <div class="form-group">
                          <label class="col-sm-3 control-label">Review On</label>
                          <div class="col-sm-9">
<!--                             <input type="text" name="title" class="form-control"  data-required="true" placeholder="Course Title" required> -->   

                          <?php echo Form::select('review_on',$reviewon,null,['class'=>'form-control']); ?>

                          </div>
                        </div>
                         <div class="form-group">
                          <label class="col-sm-3 control-label">Reviewer's Name</label>
                          <div class="col-sm-9">
                            <input type="text" name="review_by"  value="<?php echo e($review->review_by); ?>" class="form-control"  data-required="true" placeholder="Course Review" required>   
                          </div>
                        </div>
                         <div class="line line-dashed line-lg pull-in"></div>
                      <!--   <div class="form-group">
                          <label class="col-sm-3 control-label"> Price</label>
                          <div class="col-sm-9">
                            <input type="text" name="price"  class="form-control" placeholder="Starting Price" required>
                          </div>
                        </div> -->

                        

                        <div class="form-group">
                          <label class="col-sm-3 control-label">Comments</label>
                          <div class="col-sm-9">
                          
                            <textarea id="summernote" name="comment" class="form-control" required><?php echo $review->comment; ?></textarea> 
                          

                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-sm-3 control-label">Set Featured</label>
                          <div class="col-sm-9">
                          Yes:<?php echo e(Form::radio('set_featured', 'Y')); ?>

                          No:<?php echo e(Form::radio('set_featured', 'N')); ?>


                          </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                  
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                          <label class="col-sm-3 control-label">Status</label>
                          <div class="col-sm-9">
                         <?php echo Form::select('status',['A'=>'Active','I'=>'Inactive'],null,['placeholder'=>'select status']); ?>


                          </div>
                         </div>
                    
                    
                      

                       <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                          <label class="col-sm-3 control-label">Reviewer's Images(Min Dimension:90x90)</label>
                          <div class="col-sm-9">

            <div class="input_fields_wrap">
                
                
                  <div style="margin-bottom:10px;">
                       <input type="file" name="image_name" class="GalleryImage" id="img0"/> &nbsp 
                  </div>

           </div>      
                       </div>
                     </div>
                  <footer class="panel-footer text-right bg-light lter">
                       
                          <input type="submit" class="btn btn-success btn-s-xs" value="Submit"/>

                        <a href="<?php echo e(url('/admin/course-management')); ?>" class="btn btn-danger">Cancel</a>
                      </footer>


                     </div>

                     <?php echo e(Form::close()); ?>

                      
                      
          

</section>
</section>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

 <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>