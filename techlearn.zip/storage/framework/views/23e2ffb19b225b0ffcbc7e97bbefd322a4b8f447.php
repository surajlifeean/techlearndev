<?php $__env->startSection('content'); ?>


<section id="content">
<section class="vbox">
<section class="scrollable padder">

              <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Home</a></li>
                <li><a href="<?php echo e(route('course-management.index')); ?>">Course Video Management</a></li>
                <li><a href="<?php echo e(route('course-management.create')); ?>">Add Video</a></li>
               
              </ul>  
                      <header class="panel-heading">
                        <strong>Enter The Course Video for <?php echo e($course->title); ?></strong>
                      </header>

<?php if(count($coursevideo)!=0): ?>
<?php echo e(Form::model($coursevideo,['route' =>['course-video-management.update',$coursevideo[0]->course_id],'method' =>'PUT', 'files' => true, 'class'=>'form-horizontal course-form','data-parsley-validate'])); ?>

<?php else: ?>
<?php echo e(Form::open(['route' => 'course-video-management.store','files' => true, 'class'=>'form-horizontal course-form','data-parsley-validate'])); ?>

<?php endif; ?>

<input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

<?php if(count($coursevideo)!=0): ?>
<table id="myTable" class=" table order-list">
    <thead>
        <tr>
            <td>Level</td>
            <td>video</td>
            <td>Topic</td>
            <td>Description</td> 
        </tr>
    </thead>
    <tbody>
<?php $vid_array=array(); ?>
<?php $__currentLoopData = $coursevideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($coursevideo[$key+1])): ?>
        <?php    
            $level=$coursevideo[$key+1]->level; 
        ?>
        <?php else: ?>
            <?php 
            $level=0;    
            ?>
        <?php endif; ?>

        
        <?php if($value->level!=$level): ?>
        <tr>
          <?php 

            $index=$key+13;

          ?>
            <?php array_push($vid_array,$value->video_id)  ?>

            <td class="col-sm-1">
                <select name="level[<?php echo e($index); ?>]" class="form-control">
                  <option value="1" <?php if($value->level==1): ?>selected="selected" <?php endif; ?>>1</option>
                  <option value="2" <?php if($value->level==2): ?>selected="selected" <?php endif; ?> >2</option>
                  <option value="3" <?php if($value->level==3): ?>selected="selected" <?php endif; ?> >3</option>
                  <option value="4" <?php if($value->level==4): ?>selected="selected" <?php endif; ?>>4</option>
                  <option value="5" <?php if($value->level==5): ?>selected="selected" <?php endif; ?>>5</option>
                  <option value="6" <?php if($value->level==6): ?>selected="selected" <?php endif; ?>>6</option>
                  <option value="7" <?php if($value->level==7): ?>selected="selected" <?php endif; ?>>7</option>
                  <option value="8" <?php if($value->level==8): ?>selected="selected" <?php endif; ?>>8</option>
                  <option value="9" <?php if($value->level==9): ?>selected="selected" <?php endif; ?>>9</option>
                  <option value="10" <?php if($value->level==10): ?>selected="selected" <?php endif; ?>>10</option>
                  <option value="11" <?php if($value->level==11): ?>selected="selected" <?php endif; ?>>11</option>
                  <option value="12" <?php if($value->level==12): ?>selected="selected" <?php endif; ?> >12</option>
                </select>
            </td>
            <td class="col-sm-3">
                <?php echo e(Form::select("video_id[$index]", $videos,$vid_array, array("multiple" => true,"class"=>"form-control"))); ?>

            </td>
            <td class="col-sm-3">
                <input type="text" name="topic[<?php echo e($index); ?>]" value="<?php echo e($value->topic_name); ?>" class="form-control"/>
            </td>
            <td class="col-sm-4">
                <input type="text" name="description[<?php echo e($index); ?>]" value="<?php echo e($value->description); ?>" class="form-control"/>
            </td>
            <!-- <td class="col-sm-2"><a class="deleteRow"></a>

            </td> -->
            <td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>
        </tr>

         <?php 
              $vid_array=array();
        ?>
     

        <?php else: ?>

            <?php array_push($vid_array,$value->video_id)  ?>

        <?php endif; ?>

        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
     <tfoot>
        <tr>
            <td colspan="5" style="text-align: left;">
                <input type="button" class="btn btn-lg btn-block " id="addrow" value="Add Row" />
            </td>
        </tr>
        <tr>
        </tr>
    </tfoot>

</table>

<?php else: ?>

<table id="myTable" class=" table order-list">
    <thead>
        <tr>
            <td>Level</td>
            <td>video</td>
            <td>Topic</td>
            <td>Description</td> 
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="col-sm-1">
                <select name="level[0]" class="form-control">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select>
            </td>
            <td class="col-sm-3">
                <?php echo e(Form::select("video_id[0][]", $videos,null, array("multiple" => true,"class"=>"form-control"))); ?>

            </td>
            <td class="col-sm-3">
                <input type="text" name="topic[0]"  class="form-control"/>
            </td>
            <td class="col-sm-4">
                <input type="text" name="description[0]"  class="form-control"/>
            </td>
            <td class="col-sm-2"><a class="deleteRow"></a>

            </td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="5" style="text-align: left;">
                <input type="button" class="btn btn-lg btn-block " id="addrow" value="Add Row" />
            </td>
        </tr>
        <tr>
        </tr>
    </tfoot>
</table>


<?php endif; ?>

<button type="submit" class="btn btn-primary"> Submit </button>
<?php echo e(Form::close()); ?>





</section>
</section>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

 <script>
    $(document).ready(function() {
        $('.summernote').summernote();
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function () {
    var counter = 1;

    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td class="col-sm-1"><select name="level['+ counter + ']" class="form-control"><option value="1">1</option>  <option value="2">2</option> <option value="3">3</option> <option value="4">4</option> <option value="5">5</option> <option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option> </select> </td>';

        cols += '<td><select name="video_id['+counter+'][]" class="form-control" multiple><?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>"><?php echo e($value); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td>';

        cols += '<td><input type="text" class="form-control" name="topic[' + counter + ']"/></td>';

        cols += '<td><input type="text" class="form-control" name="description[' + counter + ']"/></td>';

        cols += '<td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();       
        counter -= 1
    });


});



function calculateRow(row) {
    var price = +row.find('input[name^="price"]').val();

}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('input[name^="price"]').each(function () {
        grandTotal += +$(this).val();
    });
    $("#grandtotal").text(grandTotal.toFixed(2));
}
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>