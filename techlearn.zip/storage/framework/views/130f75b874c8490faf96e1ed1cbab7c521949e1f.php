<?php $__env->startSection('content'); ?>

	  <section class="profile-section clearfix">
			<div class="container">
                <div class="card profile-card">
                   <div class="d-md-flex mb-3 d-sm-flex align-items-center justify-content-between">
                     <div class="propic">
                       <img src="<?php echo e(asset('images/user.jpg')); ?>" alt="">  
                     </div>
                     <div class="pro-details">
                       <ul>
                         <li><span>Student Id - </span><?php echo e(Auth::user()->student_id); ?></li>
                         <li><span>Name  - </span><?php echo e(Auth::user()->fname.' '.Auth::user()->lname); ?></li>
                         <li><span>Course  - </span><?php echo e(Auth::user()->userCourse->title); ?></li>  

                         <?php 
                         $date=Auth::user()->created_at;
                         $duration=Auth::user()->userCourse->duration;
                         $mod_date = strtotime($date."+".$duration." days") ?>
                         <li><span>Duration - </span><?php echo e(date('d.m.Y',strtotime(Auth::user()->created_at))); ?> to <?php echo e(date('d.m.Y',$mod_date)); ?></li>
                       </ul>     
                     </div>      
                   </div>  
                    
                   <div class="button-set">
                       <a href="<?php echo e(route('pdf',Auth::user()->id)); ?>"  class="button-small">Invoice</a>
                       <a href="<?php echo e(route('education.index')); ?>"  class="button-small">Education</a>
                       <a href="#"  class="button-small">Business</a>
                   </div>     
                </div>       
            </div>
	  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>