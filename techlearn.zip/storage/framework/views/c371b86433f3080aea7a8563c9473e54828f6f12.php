<?php $__env->startSection('content'); ?>


<section id="content">
<section class="vbox">
<section class="scrollable padder">

 <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Home</a></li>
                <li><a href="<?php echo e(route('course-management.index')); ?>">Banner Management</a></li>
                <li><a href="<?php echo e(route('course-management.create')); ?>">Add Banner</a></li>
               
              </ul>

 
                      <header class="panel-heading">
                        <span class="h4">Add Banner</span>
                      </header>

                      
                 
                     
                      <?php echo e(Form::open(['route' => 'banner-management.store','files' => true, 'class'=>'form-horizontal course-form','data-parsley-validate'])); ?>

                      <div class="panel-body">                   
                    
                        

                        <div class="form-group">
                          <label class="col-sm-3 control-label">Banner Text</label>
                          <div class="col-sm-9">  
                            <textarea id="summernote" name="banner_text" class="form-control" required></textarea> 
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-sm-3 control-label">Status</label>
                          <div class="col-sm-9">
                          Yes:<?php echo e(Form::radio('status', 'A')); ?>

                          No:<?php echo e(Form::radio('status', 'I')); ?>


                          </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                       <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                          <label class="col-sm-3 control-label">Banner Images(Min Dimension:1920x660)</label>
                          <div class="col-sm-9">

            <div class="input_fields_wrap">
                
                
                  <div style="margin-bottom:10px;">
                       <input type="file" name="image_name" class="GalleryImage" id="img0" required /> &nbsp 
                  </div>

           </div>      
                       </div>
                     </div>
                  <footer class="panel-footer text-right bg-light lter">
                       
                          <input type="submit" class="btn btn-success btn-s-xs" value="Submit"/>

                        <a href="<?php echo e(url('/admin/banner-management')); ?>" class="btn btn-danger">Cancel</a>
                      </footer>


                     </div>

                     <?php echo e(Form::close()); ?>

                      
                      
          

</section>
</section>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

 <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>