   <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
                
                <!-- nav -->
                <nav class="nav-primary hidden-xs">
                  <ul class="nav">
                    <li>
                      <a href="#layout"  >
                        <i class="fa fa-columns icon">
                          <b class="bg-warning"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>User Mngt.</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="<?php echo e(route('users.index')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>User List</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li >
                      <a href="#uikit"  >
                        <i class="fa fa-flask icon">
                          <b class="bg-success"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>Banner Mngt.</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="<?php echo e(route('banner-management.create')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Add Banner</span>
                          </a>
                        </li>
                        <li >
                          <a href="<?php echo e(route('banner-management.index')); ?>">                                                                                    
                            <i class="fa fa-angle-right"></i>
                            <span>Banner Listing</span>
                          </a>
                        </li>
                     
                       
                      </ul>
                    </li>
                    <li >
                      <a href="#pages"  >
                        <i class="fa fa-file-text icon">
                          <b class="bg-primary"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>Course Mngt.</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="<?php echo e(route('course-management.create')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Add</span>
                          </a>
                        </li>
                         <li >
                          <a href="<?php echo e(route('course-management.index')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>List</span>
                          </a>
                        </li>


                        
                      </ul>
                    </li>
                    <li >
                      <a href="<?php echo e(route('review-management.index')); ?>"  >
                        <i class="fa fa-envelope-o icon">
                          <b class="bg-primary dker"></b>
                        </i>
                        <span>Review Mngt.</span>
                      </a>
                    </li>

                    <li>
                      <a href="#layout"  >
                        <i class="fa fa-columns icon">
                          <b class="bg-warning"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>Video Mngt.</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="<?php echo e(route('video-management.index')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Video List</span>
                          </a>
                        </li>
                        <li >
                          <a href="<?php echo e(route('video-management.create')); ?>" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Add</span>
                          </a>
                        </li>

                      </ul>
                    </li>

                    
                  </ul>
                </nav>
                <!-- / nav -->
              </div>